
package ciclofor;
import java.util.Scanner;

public class CicloFor {

   
    public static void main(String[] args) {
        ciclo();
        
        
    }
  public static void ciclo() {
      Scanner scanner = new Scanner(System.in);
      
      System.out.println("Inicio ");
      int inicio = scanner.nextInt();
      
      System.out.println("Limite ");
      int limite = scanner.nextInt();
      
      System.out.println("Incremento: ");
      int incremento = scanner.nextInt();
      
      if (inicio < limite){
          // crear lista de n�meros del 1 al 10 con el ciclo for 
          for (int numero = inicio; numero <=limite; numero +=incremento) {
              System.out.println("Numero actual es " + numero);          
          }
          
      }else if (limite < inicio){
          for (int numero = inicio; numero >= limite; numero -= incremento) {
          System.out.println("N�mero actual es " + numero);
      }
          
      }else { 
          System.out.println("El inicio es identico al limite " + inicio + "=" + limite );
      }
  }
    
    //Eercicico 1. Solicitar una cantidad determinada de n�mero secuenciales y calcular la suma total de estos
  public static void ejercicio(){
      Scanner scanner = new Scanner (System.in);
      
      System.out.println("Cuantos n�meros quiere sumar");
      int limite = scanner.nextInt();
      
      System.out.println("Desde que numero desea iniciar");
      int inicio = scanner.nextInt();
      System.out.println("Incremento ");
      int incremento = scanner.nextInt();
      
      if (inicio < limite){
          //crear lista de n�meros del 1 al 10 cliclo for 
          for (int numero = inicio; numero <= limite; numero += incremento) {
              System.out.println("N�mero actual es  " + numero);
          }
      } else if (limite < inicio){
  }
  }
  public static void ejercicio4() {
        Scanner scanner = new Scanner(System.in);
        int edad;
        int mayorDe18 = 0;
        int mayorDe175 = 0;
        float estatura, sumaEstatura;
        double promedioEstatura;
        
        for (int i = 0; i < 5; i++) {
            System.out.println("Edad: ");
            edad = scanner.nextInt();
            
            if (edad > 18){
                mayorDe18++;
            }
            System.out.println("Estatura: ");
            estatura = scanner.nextFloat();
            if (estatura > 1.75){
                mayorDe175++;
            }
            estatura += estatura;
            //promedioEstatura = estatura/5;
        }
        System.out.println("Mayor de 18 a�os:  " + mayorDe18);
        System.out.println("Mayor de 1.75: " + mayorDe175);
    }
    

    }


      

       
      
             
              

